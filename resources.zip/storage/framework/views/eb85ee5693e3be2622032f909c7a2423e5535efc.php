<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\HP\Documents\2022-web-work\2_bank\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>