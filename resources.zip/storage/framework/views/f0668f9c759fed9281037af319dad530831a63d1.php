<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
            <div class="card" id="statement">
                <div class="card-header">
                    <h6 class="m-0 font-weight-bold">Statement of Account</h6>
                </div>
                <div class="card-body p-0">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">DATE & TIME</th>
                                <th scope="col">AMOUNT</th>
                                <th scope="col">TYPE</th>
                                <th scope="col">DETAILS</th>
                                <th scope="col">BALANCE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $statement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($i); ?></th>
                                <td><?php echo e(date('d-m-Y h:i A', strtotime($s['datetime']))); ?></td>
                                <td><?php echo e($s['amount']); ?></td>
                                <td><?php echo e($s['type']); ?></td>
                                <td><?php echo e($s['details']); ?></td>
                                <td><?php echo e($s['balence']); ?></td>
                            </tr>
                            <?php ($i++); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div><?php /**PATH C:\Users\HP\Documents\2022-web-work\2_bank\resources\views/statement1.blade.php ENDPATH**/ ?>