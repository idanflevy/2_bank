<?php

namespace App\Http\Controllers;

//use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Deposits;
use App\Models\Withdraw;
use App\Models\Transfer;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth']);
        //$this->middleware('auth:api');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $balence = $this->getBalence();

        // $users = DB::table('users')->simplePaginate(15);



        return view(
            'home',
            compact($balence),
            [
                'statement' => compact('statement')
            ]

        );
        // return view('user-home', compact('balence'));
    }

    public function index1()
    {
        $balence = $this->getBalence();
        $statement = $this->statement1();

        // compact('balence'),

        return view('home', [
            'balence' => ($balence),
            'statement' => ($statement)
        ]);
        //return $this->sendResponse($shipschedule, 'schedule list');
    }

    public function balance()
    {
        $balence = $this->getBalence();
        // return view('uhome', compact('balence'));
        return $this->sendResponse('Customer Account Balance');
    }

    public function deposit()
    {
        return view('deposit');
    }
    public function saveDeposit(Request $request)
    {
        $message = [
            'min' => 'The :attribute must be above :min $'
        ];
        $validator = Validator::make($request->all(), [
            'amount' => 'required|min:1|regex:/^\d+(\.\d{1,2})?$/'
        ], $message)->validate();
        $deposit = new Deposits;
        $deposit->user_id = Auth::user()->id;
        $deposit->amount = $request->amount;
        $save = $deposit->save();
        if ($save) {
            return back()->with('success', 'Cash deposited successfully');
        } else {
            return back()->with('error', 'Something encountered with cash deposit. Please try again');
        }
    }
    public function withdraw()
    {
        return view('withdraw');
    }
    public function saveWithdraw(Request $request)
    {
        $message = [
            'min' => 'The :attribute must be above :min $'
        ];
        $validator = Validator::make($request->all(), [
            'amount' => 'required|min:1|regex:/^\d+(\.\d{1,2})?$/'
        ], $message)->validate();
        $balence = $this->getBalence();
        $amount = $request->amount;
        if ($balence < $amount) {
            return redirect()->back()->with('error', 'Insufficient fund to withdraw');
        } else {
            $withdraw = new Withdraw;
            $withdraw->user_id = Auth::user()->id;
            $withdraw->amount = $amount;
            $save = $withdraw->save();
            if ($save) {
                return back()->with('success', 'Cash withdrawed successfully');
            } else {
                return back()->with('error', 'Something encountered with cash withdraw. Please try again');
            }
        }
    }

    //Tranfer
    public function transfer()
    {
        return view('transfer');
    }
    public function saveTransfer1(Request $request)
    {
        $message = [
            'min' => 'The :attribute must be above :min $'
        ];
        $validator = Validator::make($request->all(), [
            // 'email' => 'required|string|email|max:255',
            'amount' => 'required|min:1|regex:/^\d+(\.\d{1,2})?$/',
            'account_no' => 'required|min:16|regex:/^\d+(\.\d{1,2})?$/'

        ], $message)->validate();
        $email = $request->email;
        $amount = $request->amount;
        $balence = $this->getBalence();
        if ($email === Auth::user()->email) {
            return redirect()->back()->with('error', 'You cannot transfer fund to yourself. Please try with another registered email');
        } else {
            $email_exists = User::where('email', $email)->first();
            if (!$email_exists) {
                return redirect()->back()->with('error', 'Email address not found. Please try with registered e-mail address.');
            } else {
                $transferToEmail = $email_exists->id;
            }
            if ($amount > $balence) {
                return redirect()->back()->with('error', 'Insufficient fund to transfer');
            }
            $transfer = new Transfer;
            $transfer->transferFrom = Auth::user()->id;
            $transfer->transferTo = $transferToEmail;
            $transfer->amount = $amount;
            $save = $transfer->save();
            if ($save) {
                return back()->with('success', 'Fund Transfered successfully');
            } else {
                return back()->with('error', 'Something encountered with fund transfer. Please try again');
            }
        }
    }

    public function saveTransfer(Request $request)
    {
        $message = [
            'min' => 'The :attribute must be above :min $'
        ];
        $validator = Validator::make($request->all(), [
            // 'email' => 'required|string|email|max:255',
            'amount' => 'required|min:1|regex:/^\d+(\.\d{1,2})?$/',
            'account_number' => 'required|min:16|regex:/^\d+(\.\d{1,2})?$/'

        ], $message)->validate();
        $account_number = $request->account_number;
        $amount = $request->amount;
        $balence = $this->getBalence();
        if ($account_number === Auth::user()->account_number) {
            return redirect()->back()->with('error', 'You cannot transfer fund to yourself. Please try with another account Number');
        } else {
            $account_number_exists = User::where('account_number', $account_number)->first();
            if (!$account_number) {
                return redirect()->back()->with('error', 'Account Number not found. Please re-check');
            } else {
                $transferTo_account_number = $account_number_exists->id;
            }
            if ($amount > $balence) {
                return redirect()->back()->with('error', 'Insufficient fund to transfer');
            }
            $transfer = new Transfer;
            $transfer->transferFrom = Auth::user()->id;
            $transfer->transferTo = $transferTo_account_number;
            $transfer->amount = $amount;
            $save = $transfer->save();
            if ($save) {
                return back()->with('success', 'Fund Transfered successfully');
            } else {
                return back()->with('error', 'Something encountered with fund transfer. Please try again');
            }
        }
    }

    public function statement1()
    {
        $statement = [];
        $deposit = Auth::user()->deposits()->get();
        $balence = 0;
        foreach ($deposit as $d) {
            $balence += $d->amount;
            $statement[] = [
                'datetime' => $d->created_at,
                'amount' => number_format($d->amount, 2),
                'type' => 'Credit',
                'details' => 'Deposit',
                'balence' => number_format($balence, 2)
            ];
        }
        $withdraw = Auth::user()->withdraws()->get();

        foreach ($withdraw as $w) {
            $balence -= $w->amount;
            $statement[] = [
                'datetime' => $w->created_at,
                'amount' => number_format($w->amount, 2),
                'type' => 'Debit',
                'details' => 'Withdraw',
                'balence' => number_format($balence, 2)
            ];
        }
        $transfer = Transfer::where('transferFrom', Auth::user()->id)->orWhere('transferTo', Auth::user()->id)->get();

        $creditTransfer = $transfer->where('transferTo', Auth::user()->id);
        foreach ($creditTransfer as $ct) {
            $balence += $ct->amount;
            $user = User::find($ct->transferTo);
            $statement[] = [
                'datetime' => $ct->created_at,
                'amount' => number_format($ct->amount, 2),
                'type' => 'Credit',
                'details' => 'Transfer from ' . $user->firstname . '/' .  $user->account_number,
                'balence' => number_format($balence, 2)
            ];
        }
        $debitTransfer = $transfer->where('transferFrom', Auth::user()->id);

        foreach ($debitTransfer as $dt) {
            $balence -= $dt->amount;
            $user = User::find($dt->transferTo);
            $statement[] = [
                'datetime' => $dt->created_at,
                'amount' => number_format($dt->amount, 2),
                'type' => 'Debit',
                'details' => 'Transfer to ' . $user->firstname . '/' . 'acct' . $user->account_number,
                'balence' => number_format($balence, 2)
            ];
        }
        $statement = collect($statement)->sortBy('datetime');
        $balence = 0;
        $state = [];
        foreach ($statement as $s) {
            if ($s['type'] == 'Debit') {
                $balence -= $s['amount'];
            } else {
                $balence += $s['amount'];
            }
            $s['balence'] = number_format($balence, 2);
            $state[] = $s;
        }
        $statement = $state;

        return $statement;
    }
    public function statement()
    {
        $statement = [];
        $deposit = Auth::user()->deposits()->get();
        $balence = 0;
        foreach ($deposit as $d) {
            $balence += $d->amount;
            $statement[] = [
                'datetime' => $d->created_at,
                'amount' => number_format($d->amount, 2),
                'type' => 'Credit',
                'details' => 'Deposit',
                'balence' => number_format($balence, 2)
            ];
        }
        $withdraw = Auth::user()->withdraws()->get();

        foreach ($withdraw as $w) {
            $balence -= $w->amount;
            $statement[] = [
                'datetime' => $w->created_at,
                'amount' => number_format($w->amount, 2),
                'type' => 'Debit',
                'details' => 'Withdraw',
                'balence' => number_format($balence, 2)
            ];
        }
        $transfer = Transfer::where('transferFrom', Auth::user()->id)->orWhere('transferTo', Auth::user()->id)->get();

        $creditTransfer = $transfer->where('transferTo', Auth::user()->id);
        foreach ($creditTransfer as $ct) {
            $balence += $ct->amount;
            $user = User::find($ct->transferTo);
            $statement[] = [
                'datetime' => $ct->created_at,
                'amount' => number_format($ct->amount, 2),
                'type' => 'Credit',
                'details' => 'Transfer from ' . $user->firstname . '/' . 'acct' . $user->account_number,
                'balence' => number_format($balence, 2)
            ];
        }
        $debitTransfer = $transfer->where('transferFrom', Auth::user()->id);

        foreach ($debitTransfer as $dt) {
            $balence -= $dt->amount;
            $user = User::find($dt->transferTo);
            $statement[] = [
                'datetime' => $dt->created_at,
                'amount' => number_format($dt->amount, 2),
                'type' => 'Debit',
                'details' => 'Transfer to ' . $user->firtsname . '/' . 'acct' . $user->account_number,
                'balence' => number_format($balence, 2)
            ];
        }
        $statement = collect($statement)->sortBy('datetime');
        $balence = 0;
        $state = [];
        foreach ($statement as $s) {
            if ($s['type'] == 'Debit') {
                $balence -= $s['amount'];
            } else {
                $balence += $s['amount'];
            }
            $s['balence'] = number_format($balence, 2);
            $state[] = $s;
        }
        $statement = $state;
        return view('statement', compact('statement'));
    }
    public function getBalence()
    {
        $balence = 0;
        $deposit = Auth::user()->deposits()->get();
        foreach ($deposit as $d) {
            $balence += $d->amount;
        }
        $withdraw = Auth::user()->withdraws()->get();
        foreach ($withdraw as $w) {
            $balence -= $w->amount;
        }
        $transfer = Transfer::where('transferFrom', Auth::user()->id)->orWhere('transferTo', Auth::user()->id)->get();
        $creditTransfer = $transfer->where('transferTo', Auth::user()->id);
        $debitTransfer = $transfer->where('transferFrom', Auth::user()->id);
        foreach ($creditTransfer as $ct) {
            $balence += $ct->amount;
        }
        foreach ($debitTransfer as $dt) {
            $balence -= $dt->amount;
        }
        return $balence;
    }
}
