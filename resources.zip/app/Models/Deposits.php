<?php

namespace  App\Models;

use Illuminate\Database\Eloquent\Model;

class Deposits extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'deposits';
}
